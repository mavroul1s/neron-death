# CLAUDE.md

Project context for Claude Code. Read this before touching anything. The companion file `protocol_weeks_1_2_v2.md` in this folder is the authoritative experimental specification — when this file and the protocol disagree, **the protocol wins** and you should flag the discrepancy rather than silently pick one.

---

## 1. What this project is

A research codebase for a single paper on **dead and dormant neurons in continual learning**.

Working title: *Recycling the Living: Dormant-Neuron Interventions Do Not Work by Reviving Dead Units.*

The scientific question: when a network trained on non-stationary data loses its ability to learn, is the accumulation of inactive neurons a **cause** of that loss, or merely a **correlate**? The literature assumes cause and has built ~15 mitigation methods on that assumption. We have evidence the assumption is wrong.

This is an **analysis paper**, not a method paper. We are not proposing a new algorithm. Correctness of measurement matters far more than performance, cleverness, or speed. If you are ever choosing between a faster implementation and an obviously-correct one, choose obviously-correct and leave a comment.

## 2. The four claims the code exists to test

| ID | Claim | What the code must make measurable |
|---|---|---|
| **C1** | ReDo's benefit does not come from reviving dead neurons | Composition of every recycled set: how many were genuinely dead vs merely quiet |
| **C2** | The published definitions of "dead" disagree materially | All four death metrics computed simultaneously on the same activations |
| **C3** | L2 helps plasticity while *increasing* dead units; online norm *increases* the units it was designed to prevent | Faithful replication of Dohare et al. Fig. 4b plus the C2 decomposition |
| **C5** | Adam-induced death is a distinct mechanism | Per-neuron death timing relative to task boundaries |
| **C4** | (analysis-only) neuron mortality follows characterisable dynamics | Per-neuron time series logged at every task boundary |

Every design decision should be traceable to one of these. If a proposed feature serves none of them, it is out of scope.

## 3. Environment

- **Compute: Kaggle notebooks. 2× NVIDIA T4 (16 GB each), 30 GPU-hours/week, hard 12-hour session cap.**
- Models are small MLPs (~1M params). A single T4 is never saturated, so **run two independent configs in parallel, one per GPU**, via `CUDA_VISIBLE_DEVICES`. Never write code that assumes both GPUs belong to one run.
- `/kaggle/working` **does not persist**. Results must be pushed to a versioned Kaggle Dataset at the end of every session.
- No internet access is assumed at runtime. Cache MNIST/CIFAR-10 as a Kaggle Dataset; do not add download-at-runtime code paths.
- PyTorch. No distributed training, no mixed precision, no `torch.compile` — the numerical fidelity of activation statistics matters more than throughput, and these features have all been observed to alter small-magnitude activations.

### Hard rules for job design
- **Every job must complete in under 11 hours.** The 12-hour cut is abrupt and unannounced.
- Checkpoint every 10 tasks: model state, optimizer state, RNG states (torch, numpy, python), current task index, path to the partial parquet log.
- Every run must be resumable by `run_id` alone.

## 4. Repository layout

```
neuron-death/
├── CLAUDE.md                     # this file
├── protocol_weeks_1_2_v2.md      # authoritative experiment spec
├── configs/
│   ├── analysis_plan.json        # FROZEN — see §7
│   └── <run configs>.json
├── src/
│   ├── data.py                   # permuted MNIST, label-shuffled CIFAR-10
│   ├── models.py                 # MLP; activation + norm are config fields
│   ├── probes.py                 # ALL metrics live here, nowhere else
│   ├── interventions.py          # ReDo, random-matched, inverse-matched, S&P
│   ├── train.py                  # task loop, checkpointing, logging
│   └── analysis/                 # post-hoc only; never imported by train.py
├── tests/
├── runs/
│   ├── LEDGER.md                 # run_id, config hash, date, status, GPU-hours
│   └── <run_id>/                 # config.json, metrics.parquet, neurons.parquet, checkpoints
└── notebooks/                    # thin Kaggle entry points only
```

Rules:
- **All metrics live in `src/probes.py`.** If a metric is computed inline in `train.py`, that is a bug — it will drift from the version used in analysis.
- `notebooks/` contains no logic. Kaggle notebooks import from `src/` and call one function.
- `src/analysis/` must never be imported by training code.

## 5. Metric definitions — implement exactly as written

These come from the four source papers. Do not "improve" them. Deviating breaks comparability with published numbers, which is the point of using them.

**Probe batches.** Two fixed batches of 2048 examples: one from the *current* task's distribution, one from a *reference* distribution that never changes across the whole run. Compute every metric on both and log both. The reference batch is what lets us separate "the neuron is dead" from "the input distribution moved".

### 5.1 Four death metrics (C2)

```
dead_exact        h(x) == 0 for ALL probe inputs.
                  Dohare et al. 2024. Exact comparison to zero — do NOT use a tolerance.

dormant_tau[τ]    Sokar et al. 2023:
                    s_i^l = E_x|h_i^l(x)| / ( (1/H^l) * Σ_k E_x|h_k^l(x)| )
                  Neuron is τ-dormant if s_i^l <= τ.
                  Compute for τ ∈ {0, 0.01, 0.025, 0.05, 0.1, 0.25}.
                  NOTE: normalised by the LAYER MEAN. This is a RELATIVE measure.
                  Its failure mode is the point of C2 — do not "fix" it.

dead_absolute[a]  E_x|h(x)| < a, for a FIXED threshold a ∈ {1e-6, 1e-4, 1e-2}.
                  Proposed by us. No layer normalisation. This is the control that
                  exposes dormant_tau's blind spot.

saturated         For bounded activations only (tanh/sigmoid):
                  |h(x) − extreme| < ε for all probe inputs.
                  Return None for unbounded activations, never 0.
```

### 5.2 Effective rank

Use the **entropy-based** definition of Roy & Vetterli (2007), as used by Dohare et al. — **not** the `srank_δ` of Kumar et al. 2021:

```
Given singular values σ_1..σ_q of the layer activation matrix,
  p_k = σ_k / ||σ||_1
  erank = exp( -Σ_k p_k log p_k )
```

Guard against `p_k = 0` (use `p_k log p_k = 0` there). Compute on the 2048-example probe batch.

### 5.3 Other per-layer metrics

`‖θ‖₂` and mean `|w|` (log both — Dohare reports mean absolute); gradient norm averaged over the last 100 steps of the task; average sign entropy of pre-activations (Lewandowski et al. 2024).

### 5.4 Per-neuron log (C4)

One row per (run, task, layer, neuron), written at every task boundary:

```
run_id, task_idx, layer_idx, neuron_idx,
mean_abs_act, frac_inputs_active, exact_zero_flag,
sokar_score, preact_mean, preact_std,
w_in_norm, w_out_norm, bias, grad_norm_neuron,
was_recycled_this_task
```

Parquet. This dataset is **not recoverable retrospectively** — if a run completes without it, the run is wasted. Treat a missing per-neuron log as a hard failure, not a warning.

## 6. Interventions — implement exactly

### ReDo (Sokar et al. 2023, Algorithm 1)

Every `F = 1000` optimizer steps:
1. Compute `s_i^l` for every neuron using a batch of 64 examples (their default; they show batch size 32–1024 gives near-identical results).
2. For each neuron with `s_i^l <= τ`:
   - **re-initialise incoming weights** by sampling from the *original* initialisation distribution for that layer,
   - **set outgoing weights to zero.**

Zeroing the outgoing weights is what preserves the current function. Getting this wrong silently turns ReDo into a much more destructive intervention and will produce plausible-looking but meaningless results. A known reimplementation bug is applying the mask to incoming but not outgoing weights — check both.

### Random-matched(τ) — our control, and the crux of C1

At every recycling event: compute the τ-dormant set, take `k = |τ-dormant set|`, then recycle `k` neurons **chosen uniformly at random** from that layer using the identical re-initialisation procedure.

`k` must be **recomputed at every event**, per layer. It is not a fixed fraction and not a schedule. Sokar's random baseline used a fixed percentage on a cosine schedule, which confounds *which* neurons with *how many*; the whole point of our control is to remove that confound.

### Inverse-matched(τ)

Same `k`, but the `k` **highest**-scoring neurons. Expected to collapse performance — this is a sanity check replicating Sokar Fig. 15.

### Recycled-set composition logging (the C1 headline measurement)

At every recycling event, for the set actually recycled, log:

```
run_id, step, layer_idx, tau, k,
n_dead_exact          # of the recycled, how many were genuinely dead
n_alive_but_quiet     # of the recycled, how many had frac_inputs_active > 0
mean_sokar_score
```

This produces the paper's main figure. If this table is missing or wrong, the run has no value.

## 7. Non-negotiables

**`configs/analysis_plan.json` is frozen.** It contains the outcome measure, the task windows, the decision thresholds (|Δ| < 1 pp for "≈"; Δ > 2 pp with CI excluding zero for "≫"), and the number of seeds. It was committed with a timestamp before any data existed.

**Never modify it. Never suggest modifying it after seeing results.** If a result is ambiguous, the pre-specified response is *add seeds*, not *adjust the threshold*. If you notice a genuine specification error, say so explicitly and stop — do not fix it unilaterally.

**Never silently change a hyperparameter.** If a run needs a different learning rate, that is a new config file with a new `run_id`, not an edit to an existing one.

**Determinism is required.** Seed torch, numpy, and python `random`; set `torch.backends.cudnn.deterministic = True` and `benchmark = False`. If a source of nondeterminism cannot be removed, document it in the run config rather than ignoring it.

**Statistics.** Report IQM with stratified bootstrap 95% CIs (Agarwal et al. 2021), never bare means over seeds. This field has been explicitly criticised for weak evaluation practice; we are not adding to that.

## 8. Testing

`tests/` must contain, at minimum:

1. **Forced-dead network:** clamp biases very negative; assert `dead_exact` detects every such unit.
2. **Uniformly shrunken layer:** scale a whole layer's activations toward zero; assert `dormant_tau` reports **near 0%** (it should miss this) while `dead_absolute` catches it. **If `dormant_tau` catches it, the layer-mean normalisation is implemented wrongly.**
3. **ReDo function preservation:** with `τ = 0`, network outputs before and after a recycling event must be identical to numerical tolerance (because outgoing weights are zeroed).
4. **Random-matched cardinality:** assert `k` equals `|τ-dormant set|` per layer per event.
5. **Effective rank:** known-rank synthetic matrices give expected `erank`.
6. **Checkpoint round-trip:** save, reload, continue — losses match a run that was never interrupted.

Run tests before every batch of GPU jobs. Twenty seconds of testing beats losing a 13-hour sweep.

## 9. Out of scope

Do not add, and push back if asked to add: deep RL (Atari, DMC, any agent) · Mixture-of-Experts · sparse autoencoders · scaling-law sweeps · models above ~50M parameters · **any new reset/recycling method of our own** · distributed training · hyperparameter auto-tuning.

One permitted late addition (Week 7 only): a single nanoGPT-scale continual-language-shift arm, 3–4 runs, one figure.

## 10. Working style

- Prefer many small runs to few large ones. The statistical design needs runs as observations.
- When a result looks surprising, suspect the instrument first. Write a test that would catch the bug, then investigate.
- Comment any place where the implementation follows a paper's specific choice, with the citation, so it is not "cleaned up" later.
- Update `runs/LEDGER.md` after every session. It becomes the compute appendix.

## 11. Current status

```
Phase:        Week 1 — infrastructure COMPLETE, no GPU runs yet
Gate passed:  not yet — the gate has not been run
Next task:    1. python scripts/prepare_data.py --dataset mnist --root data
              2. upload repo + data/ as two Kaggle Datasets
              3. run notebooks/kaggle_week1_gate.ipynb (15 configs, ~1.5 h)
              4. python -m src.analysis.gate --pattern "gate_*"
Blocking:     nothing
GPU-hours used: 0 / 40 (weeks 1–2 budget)
```

**Built and tested (68 tests, all passing — `python -m pytest tests/`):**
`src/probes.py` (all four death metrics, effective rank, sign entropy, gradient
tracker, log schemas) · `src/models.py` · `src/data.py` · `src/interventions.py`
(ReDo, random-matched, inverse-matched, L2, S&P) · `src/train.py` (task loop,
sharded parquet logs, checkpoint/resume) · `src/analysis/` (IQM + stratified
bootstrap, gate evaluator) · `configs/analysis_plan.json` (**frozen
2026-08-05T14:09:03Z, before any data existed**) · configs for all five
experiments · Kaggle notebook and two-GPU launcher.

**Known gaps, deliberate:**

- `norm="online"` raises `NotImplementedError`. Online Normalization (Chiley et
  al. 2019) was not reconstructed from memory: a wrong backward-control
  approximation would still train and still produce a plausible dead-unit curve,
  silently invalidating C3. **Implement it against the paper before §B.2.**
- Protocol §A.4's "`dead_exact` must rise monotonically" is unsatisfiable as
  literal per-task monotonicity. Operationalised in the frozen plan as a
  Spearman rank correlation over tasks (network-pooled, current-task probe
  batch), positive with CI excluding zero. Recorded there with its rationale.

Keep this section current. It is the first thing to read when resuming.
