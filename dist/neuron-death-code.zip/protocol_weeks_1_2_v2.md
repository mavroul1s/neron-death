# Experimental Protocol — Weeks 1–2 (v2)
### Revised after reading Sokar et al. 2023, Lyle et al. 2023, Lyle et al. 2024, Dohare et al. 2024

**What changed from v1 and why.** The ε-dissociation experiment is partially pre-empted: Sokar et al. already ran LeakyReLU(0.01) in RL (Appendix C.1, Fig. 21) and found the phenomenon persists; Dohare et al. tested six activation functions including leaky-ReLU and found plasticity loss in all of them; Lyle et al. 2023 already falsified "dead units" as a causally robust predictor via an invariance argument. The ε-sweep is therefore demoted to a replication arm. The **primary experiment is now the ReDo τ-sweep with a size-matched random control**, which is not pre-empted and which directly tests the field's most-cited intervention.

**Constraints:** 2× T4 (16 GB), 30 GPU-hours/week, 12-hour session cap, single researcher.
**Budget for Weeks 1–2: 40 hours.**

---

## The four claims we are testing

| # | Claim | Status in literature |
|---|---|---|
| **C1** | ReDo's benefit does not come from reviving *dead* neurons. It comes from perturbing low-magnitude *living* ones. | Untested. Sokar's own hyperparameter search (τ=0.1 best, not τ=0) implies it but is not interpreted. |
| **C2** | The three published definitions of "dead" disagree materially on the same network. | Never measured jointly. |
| **C3** | Interventions that *help* plasticity can *increase* dead units (L2), and interventions designed to *prevent* dead units can *increase* them (online norm). | Reported in Dohare et al. Fig. 4b; never explained. |
| **C5** | Adam-induced neuron death is a distinct, identifiable mechanism separable from plasticity loss generally. | Lyle Fig. 1 and Dohare's Adam result are unconnected. |

(C4, survival analysis, needs no Week-2 experiment — only the logging built in Week 1.)

---

## Part A — Week 1: infrastructure and the reproduction gate

### A.1 Reading — DONE

Key extractions to keep on one page while you code:

- **Sokar τ-dormancy:** `sᵢˡ = E|hᵢˡ(x)| / ((1/Hˡ) Σₖ E|hₖˡ(x)|)`, τ-dormant if `sᵢˡ ≤ τ`. Note the layer-mean normalisation.
- **ReDo:** every F=1000 steps, for each τ-dormant neuron, re-initialise incoming weights from the original init distribution and **zero the outgoing weights**. Best τ reported: **0.1**.
- **Dohare dead-unit measure:** output exactly zero across a sample of 2000 images, computed at the start of each task.
- **Dohare effective rank:** entropy-based (Roy & Vetterli 2007), `erank(Φ) = exp{H(p₁…p_q)}` with `pₖ = σₖ/‖σ‖₁`. Not the srank_δ of Kumar et al. — **use Dohare's so your numbers are comparable to the *Nature* paper.**
- **Lyle falsification criterion:** a variable is ruled out as causal if its correlation with plasticity **reverses sign** across experimental interventions.

### A.2 Repository skeleton (Day 1, no GPU)

```
neuron-death/
├── configs/           # one JSON per run
├── src/
│   ├── data.py        # permuted MNIST, label-shuffled CIFAR-10
│   ├── models.py      # MLP; activation + norm are config fields
│   ├── probes.py      # ALL metrics
│   ├── interventions.py  # ReDo, random-matched, inverse, L2, S&P
│   ├── train.py       # task loop + checkpointing
│   └── analysis/
├── runs/
└── notebooks/
```

Non-negotiables: config JSON saved beside outputs; all seeds set; `cudnn.deterministic = True`; checkpoint every 10 tasks; **assume the Kaggle session dies at hour 11**.

### A.3 The probe module (Days 2–4, ~2 GPU-hours)

**Probe batch:** fixed 2048 examples from the current task, plus a fixed 2048-example *reference* batch that never changes.

**The C2 measurement — four death definitions, computed simultaneously:**

| Name | Definition | Source |
|---|---|---|
| `dead_exact` | `h(x) == 0` for **all** probe inputs | Dohare et al. 2024 |
| `dormant_tau[τ]` | Sokar score `≤ τ`, for τ ∈ {0, 0.01, 0.025, 0.05, 0.1, 0.25} | Sokar et al. 2023 |
| `dead_absolute[a]` | `E|h| < a` with a **fixed** threshold, a ∈ {1e-6, 1e-4, 1e-2} | proposed here |
| `saturated` | for bounded activations, `|h − extreme| < ε` for all inputs | Rakitianskaia & Engelbrecht 2015 |

`dead_absolute` exists to expose τ-dormancy's failure mode: a layer whose activations all shrink uniformly reports **0% dormancy** while being functionally dead, because the normalisation divides out the shrinkage. Construct this case synthetically in the unit test.

**Other per-layer metrics:** effective rank (Dohare/Roy–Vetterli), `‖θ‖₂` and mean `|w|`, gradient norm, average sign entropy of pre-activations.

**Per-neuron log (the C4 dataset — not recoverable later):**

```
run_id, task_idx, layer_idx, neuron_idx,
mean_abs_act, frac_inputs_active, exact_zero_flag,
sokar_score, preact_mean, preact_std,
w_in_norm, w_out_norm, bias, grad_norm_neuron,
was_recycled_this_task
```

Parquet, one file per run. At width 500 × 3 layers × 200 tasks this is small — log it every task boundary.

**Unit test before proceeding:** build a network with units forced dead (`b` clamped very negative) and one with a uniformly shrunken layer. Confirm `dead_exact` catches the first, `dormant_tau` **misses** the second, and `dead_absolute` catches both. If τ-dormancy does not miss the shrunken layer, your implementation of the normalisation is wrong.

### A.4 The reproduction gate (Days 5–6, ~4 GPU-hours)

**Setup — deliberately close to Dohare et al. so results are comparable, but sized for a T4:**

- Online Permuted MNIST, **200 tasks**, one pass over 60k images per task
- MLP `784 → 500 → 500 → 500 → 10`, ReLU, Kaiming init
- SGD + momentum 0.9, batch 128, lr ∈ {0.01, 0.003, 0.001}
- 5 seeds

Width 500 rather than Dohare's 2000 is a deliberate choice, not a compromise: they report plasticity loss is **most pronounced at smaller widths**, so this gives a stronger effect and a faster run. Cite their Fig. 2b middle panel when justifying it.

Expected: ~3–6 minutes per run. Five seeds × three learning rates ≈ 1.5 hours.

**Gate criterion:**

> Mean per-task accuracy over tasks 151–200 must be **≥ 3 percentage points below** tasks 1–10, with a stratified-bootstrap 95% CI excluding zero, **and** `dead_exact` must rise monotonically.

If the accuracy gate passes but dead units stay flat, **stop and tell me** — that dissociation is itself a result and changes the paper.

If the gate fails: raise the learning rate first (Dohare's largest step size shows the strongest effect), then extend to 400 tasks, then narrow to width 200. Do not weaken the criterion.

---

## Part B — Week 2: the primary experiment

### B.1 The ReDo τ-sweep with a size-matched random control (~10 GPU-hours)

This is the paper's central experiment. Same setup as A.4, best learning rate from the gate, with a recycling intervention every F = 1000 steps.

**Arms — at each τ ∈ {0, 0.01, 0.025, 0.05, 0.1, 0.25}:**

| Arm | Which neurons are recycled |
|---|---|
| **ReDo(τ)** | the τ-dormant set, per Sokar |
| **Random-matched(τ)** | a random set of **exactly the same cardinality** as the τ-dormant set, recomputed at every event |
| **Inverse-matched(τ)** | the same number of **highest**-scoring neurons |
| **None** | no intervention (baseline) |

The size-matched random control is the crux and is **not** what Sokar et al. ran. Their random baseline used a *fixed percentage on a cosine schedule*, not a per-event cardinality match to each τ. Without matching, ReDo-beats-random confounds *which* neurons are recycled with *how many*.

**10 seeds per arm. 19 configurations ≈ 190 runs × 4 min ≈ 13 hours** across two GPUs in parallel — comfortable.

**The critical logged quantity — the composition of every recycled set:**

At each recycling event, record for the neurons being recycled:
- how many had `dead_exact = True` (genuinely dead)
- how many had `frac_inputs_active > 0` (alive, merely quiet)
- their mean Sokar score

This produces the paper's headline figure: **τ on the x-axis; final accuracy and "fraction of recycled neurons that were actually dead" on twin y-axes.**

**Pre-specified predictions, written before running:**

| If | Then |
|---|---|
| Accuracy improves with τ while the truly-dead fraction of the recycled set falls | **C1 confirmed.** ReDo is not a resurrection method. |
| ReDo(τ) ≈ Random-matched(τ) at large τ | Targeting is irrelevant; only perturbation dose matters. Strongest form of C1. |
| ReDo(τ) ≫ Random-matched(τ) at every τ | C1 refuted. Targeting does matter — report it honestly; the measurement work (C2, C3) still stands. |
| Inverse-matched collapses | Sanity check passed (replicates Sokar Fig. 15). |

**Decision threshold:** "≈" means the 95% CI of the difference contains zero and |Δ| < 1 pp. "≫" means Δ > 2 pp with CI excluding zero. Commit these numbers to `configs/analysis_plan.json` with a timestamp **before** running.

### B.2 The C3 anomaly replication (~4 GPU-hours)

Direct replication of Dohare et al. Fig. 4b at our scale, with the C2 decomposition added — which is what makes it new rather than a repeat.

Arms: `backprop`, `L2` (λ ∈ {1e-4, 1e-3, 1e-2}), `shrink-and-perturb`, `online-norm`, `dropout(0.1)`. 5 seeds each ≈ 35 runs.

Target observations to confirm or refute:
- L2 improves final accuracy **while increasing** `dead_exact` and **decreasing** effective rank
- Online norm has **more** dead units than plain backprop in later tasks despite being designed to prevent them

If both replicate, you have two dissociations sitting inside a *Nature* paper that nobody has followed up. Then decompose them with C2: is L2 producing *exactly-zero* units or merely *low-magnitude* ones? That distinction is the explanation.

### B.3 The C5 optimizer arm (~3 GPU-hours)

Arms: `SGD`, `Adam (default: ε=1e-8, b₂=0.999)`, `Adam (Lyle-tuned: ε=1e-3, b₂=0.9)`, `AdamW (decoupled wd)`. 5 seeds each ≈ 20 runs.

Log the per-neuron death **timing relative to task boundaries** — Lyle's Fig. 1 mechanism predicts a death spike in the first steps after each switch, when `m̂` has updated but `v̂` has not. Nobody has shown that spike explicitly.

Additional question for AdamW: for an already-dead unit, `g = 0` but decoupled weight decay keeps shrinking the weights toward the origin. Does that eventually make revival *more* likely? This predicts a **non-monotonic** relationship between weight-decay strength and dead fraction — a striking result if it appears.

### B.4 The ε-sweep, demoted (~3 GPU-hours, optional)

ReLU vs LeakyReLU with ε ∈ {1e-4, 1e-3, 1e-2, 1e-1}, 5 seeds. Purpose is now a **dose–response replication in continual supervised learning**, filling the gap between Sokar (RL, single ε) and Dohare (six activations, toy regression). One figure, one paragraph. Cut it if Week 2 runs long.

---

## Part C — Kaggle operations

- Every job under **11 hours**; checkpoint and resume by run-id.
- Two configs in parallel, one per T4 (`CUDA_VISIBLE_DEVICES`). Your MLPs never saturate a single T4.
- Push `runs/` as a versioned **Kaggle Dataset** at the end of every session. `/kaggle/working` does not persist.
- Cache MNIST/CIFAR as a Kaggle Dataset.
- Maintain `runs/LEDGER.md`: run-id, config hash, date, status, GPU-hours. This becomes your compute appendix.

**Budget:** gate 4h · τ-sweep 13h · C3 4h · C5 3h · ε-sweep 3h · **buffer 13h**. Do not spend the buffer early; you will lose runs to bugs.

---

## Part D — Out of scope for eight weeks

Deep RL of any kind · Mixture-of-Experts · sparse autoencoders · scaling laws · anything above ~50M parameters · **proposing a new reset method**.

Single permitted addition, Week 7 only: one small transformer arm (nanoGPT-scale, continual language shift, 3–4 runs), one figure, to answer "does this generalise beyond MLPs?"

---

## Part E — What to report back at the end of Week 2

1. Did the gate pass, and how large was the plasticity drop?
2. The headline curve: final accuracy vs τ, alongside the truly-dead fraction of the recycled set.
3. ReDo(τ) minus Random-matched(τ), with CIs, at each τ.
4. Did the two C3 anomalies replicate?

Those four answers fix the structure of the entire paper.
